export default function Footer() {
  // javaScript 코드 자리
  return (
    // html 코드 자리
    <footer className="footer">하단</footer>
  );
}
